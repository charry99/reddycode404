module.exports = {
  branches: ['main'],
  tagFormat: '${version}',
};
